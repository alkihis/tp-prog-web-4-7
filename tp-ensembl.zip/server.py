from main import app

app.run(debug=True)
